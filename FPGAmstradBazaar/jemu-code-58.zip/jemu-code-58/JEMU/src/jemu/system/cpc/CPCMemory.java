package jemu.system.cpc;

import jemu.core.device.memory.*;

/**
 * Title:        JEMU
 * Description:  The Java Emulation Platform
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author
 * @version 1.0
 */

/**
 * Actual memory mapping from OUT instructions performed by the Gate Array.
 *
 * RAM is allocated in 64K blocks
 * ROM is allocated in 16K blocks
 * Multiface is allocated as a 24K block with 0000..1fff = Write-only RAM, 2000..3fff MF RAM,
 *   4000..5fff MF ROM
 */
public class CPCMemory extends DynamicMemory {

  public static final long TYPE_64K          = 0;
  public static final long TYPE_128K         = 0x01;
  public static final long TYPE_256K         = 0x0f;
  public static final long TYPE_SILICON_DISC = 0xf0;
  public static final long TYPE_512K         = 0xff;  // 8 banks of 64
  public static final long TYPE_4M           = -1L;   // 64 banks of 64 (0xffffffffffffffffL)

  protected int[] baseRAM  = new int[4];    // 16K blocks
  protected int[] baseROM  = new int[16];   // Base of each Upper ROM
  protected int[] baseCart = new int[32];   // Base address of each cartridge bank (to map banks > size of cart).
  protected int[] readMap  = new int[8];
  protected int[] writeMap = new int[8];

  protected long ramType;
  protected boolean lower = false;
  protected boolean upper = false;
  protected int upperROM = -1;
  protected int bankRAM = -1;
  protected boolean multifaceEnabled = false;
  protected boolean cartEnabled = false;
  protected boolean lowerROMInserted = false;
  protected int lowROM;        // Where the Lower ROM is mapped by the ASIC
  protected int currLow;       // Either lowROM if lower enabled or #FF
  protected int cartLowBase;   // Base Address of selected Lower ROM cartridge bank
  protected int lowROMBase;    // Base Address of Lower ROM (or cartridge bank if cartEnabled and no lower ROM)
  protected int upROMBase;     // Base Address of selected Upper ROM
  protected boolean asicRAM;   // true if ASIC RAM is enabled

  protected static final int BASE_RAM       = 0;                // 1..65 banks of 64K
  protected static final int BASE_LOWROM    = BASE_RAM + 65;    // 1 Lower ROM of 16K
  protected static final int BASE_UPROM     = BASE_LOWROM + 1;  // 16 Upper ROMS of 16K
  protected static final int BASE_CART      = BASE_UPROM + 16;  // 1 Bank of either 128K, 256K or 512K
  protected static final int BASE_ASIC      = BASE_CART + 1;    // 16K ASIC RAM
  protected static final int BASE_MULTIFACE = BASE_ASIC + 1;    // 16K RAM (#0000..#1fff write-only) and 8K ROM. 

  public CPCMemory(long type) {
    this("CPC Memory", type, BASE_MULTIFACE + 1);
  }
  
  protected CPCMemory(String name, long type, int banks) {
    super(name, 0x10000, banks);
    setRAMType(type);  // Always happens first, first 64K always gets mapped in first
    reset();
  }

  @Override
  public final void reset() {
    setRAMBank(0xc0);
    upper = false;
    lower = false;
    setLowerEnabled(true);
    upperROM = -1;
    setUpperROM(0);
    remap();
  }

  public final void setRAMType(long value) {
    ramType = value;
    getMem(BASE_RAM, 64 * KB);
    for (int i = BASE_RAM + 1; i < BASE_RAM + 9; i++) {
      if ((value & 0x01) != 0)
        getMem(i, 64 * KB);
      else
        freeMem(i, 64 * KB);
      value >>= 1;
    }
  }
  
  public long getRAMType() {
    return ramType;
  }

  public void setLowerROM(byte[] data) {
    lowerROMInserted = setROM(BASE_LOWROM, data);
    // TODO: Invalid if no cartridge and no lower ROM
    lowROMBase = !cartEnabled || (lowerROMInserted && cartLowBase == 0) ? baseAddr[BASE_LOWROM] :
      baseAddr[BASE_CART] + cartLowBase;
    currLow = lower && lowROMBase != -1 ? lowROM : 0xff;
    remap();
  }

  public void setUpperROM(int rom, byte[] data) {
    rom &= 0x0f;
    setROM(BASE_UPROM + rom, data);
    mapCartROM(rom);
    // If this is ROM 0, map all other ROMs
    if (rom == 0)
      mapOtherUpperROMs();
    remap();
  }
  
  protected void mapOtherUpperROMs() {
    for (int rom = 1; rom <= 15; rom++)
      mapCartROM(rom);
  }
  
  protected void mapCartROM(int rom) {
    int addr = baseAddr[BASE_UPROM + rom];
    // If there's a ROM inserted in the slot, use it
    if (addr != -1)
      baseROM[rom] = addr;
    else {
      if (rom == 7 && cartEnabled)
        baseROM[7] = baseCart[3];
      else if (rom != 0)
        baseROM[rom] = baseROM[0];  // Could be mapped to cart or lower ROM
      else
        // -1 if there's no Upper ROM at all
        baseROM[0] = cartEnabled ? baseCart[1] : -1;
    }
  }

  protected boolean setROM(int base, byte[] data) {
    return setROM(base, data, 16 * KB);
  }
  
  protected boolean setROM(int base, byte[] data, int size) {
    if (data == null || data.length == 0) {
      freeMem(base, size);
      return false;
    }
    else {
      base = getMem(base, size);
      System.arraycopy(data, 0, mem, base, Math.min(size, data.length));
      return true;
    }
  }
  
  public void setMultifaceROM(byte[] data) {
    if (data == null || data.length == 0)
      freeMem(BASE_MULTIFACE, 24 * KB);
    else {
      int base = getMem(BASE_MULTIFACE, 24 * KB);
      System.arraycopy(data, 0, mem, base + 0x4000, Math.min(8 * KB, data.length));
    }
    // Don't worry about re-mapping, multiface shouldn't currently be enabled when set
  }
  
  public void setCartridge(byte[] data) {
    int size = data.length;
    if (size != 0 && size != 128 * KB && size != 256 * KB && size != 512 * KB)
      System.err.println("Warning: Unexpected cartridge size: " + data.length);
    cartEnabled = size != 0;
    // TODO: How does the Plus map banks above cartridge size?
    setROM(BASE_CART, data, 512 * KB);
    for (int bank = 0; bank < 32; bank++)
      baseCart[bank] = baseAddr[BASE_CART] + bank * 16 * KB;
  }

  public void setLowerEnabled(boolean value) {
    if (lower != value) {
      lower = value;
      currLow = value && lowROMBase != -1 ? lowROM : 0xff; 
      remap();
    }
  }

  public void setUpperEnabled(boolean value) {
    if (upper != value) {
      upper = value;
      remap();
    }
  }

  public void setUpperROM(int value) {
    if (upperROM != value) {
      upperROM = value;
      if ((value & 0x80) != 0 && cartEnabled)
        upROMBase = baseCart[value & 0x1f];
      else
        upROMBase = baseROM[value & 0x0f];
      if (upper && upROMBase != -1)
        readMap[7] = (readMap[6] = upROMBase) + 0x2000;
      else
        readMap[7] = (readMap[6] = baseRAM[3]) + 0x2000;
    }
  }

  public void setRAMBank(int value) {
    value &= 0x3f;
    if (bankRAM != value) {
      bankRAM = value;
      remapRAM();
      remap();
    }
  }

  protected void remapRAM() {
    int bankBase = ((bankRAM & 0x38) >> 3) + BASE_RAM + 1;
    bankBase = baseAddr[bankBase];
    // TODO: If the 64K block isn't available, map it to another?
    // Maybe we can use a mask
    if (bankBase == -1) {             // 64K block not available
      bankBase = baseAddr[BASE_RAM];
      bankRAM = 0;
    }
    int base = (bankRAM & 0x07) == 2 ? bankBase : baseAddr[BASE_RAM];   // 0xc2, 0xca etc.
    for (int i = 0; i < 4; i ++)
      baseRAM[i] = base + i * 0x4000;
    if ((bankRAM & 0x05) == 0x01) {        // 0xc1, 0xc3, 0xc9, 0xcb etc.
      baseRAM[3] = bankBase + 0xc000;
      if ((bankRAM & 0x02) == 0x02)        // 0xc3, 0xcb etc. Maps normal 0xc000 to 0x4000
        baseRAM[1] = base + 0xc000;
    }
    else if ((bankRAM & 0x04) == 0x04)     // 0xc4, 0xc5, 0xc6, 0xc7, 0xcc, 0xcd etc.
      baseRAM[1] = bankBase + (bankRAM & 0x03) * 0x4000;
  }

  public int getRAMBank() {
    return bankRAM | 0xc0;
  }

  @Override
  public int readByte(int address) {
    return mem[readMap[address >> 13] + (address & 0x1fff)] & 0xff;
  }

  @Override
  public int writeByte(int address, int value) {
    mem[writeMap[address >> 13] + (address & 0x1fff)] = (byte)value;
    return value & 0xff;
  }

  // Supports CPC Plus Memory Mapping
  protected void remap() {
    // Map region #0000..#3fff
    int addr;
    if (multifaceEnabled) {
      addr = baseAddr[BASE_MULTIFACE];                      // The multiface is assumed to be 16K RAM and 8K ROM
      readMap[0] = addr + 0x4000;                           // Not sure what really happens if you write to the lower 8K
      writeMap[0] = addr;
      readMap[1] = writeMap[1] = addr + 0x2000;
    }
    else {
      addr = baseRAM[0];                                    // baseRAM can be simplified to 4 rather than 8 blocks
      writeMap[1] = (writeMap[0] = addr) + 0x2000;          // ramBase[0..3] are set by out #7fxx,xx
      if (currLow == 0)                                     // Zero if ASIC RAM is enabled or ROM at #0000
        readMap[1] = (readMap[0] = lowROMBase) + 0x2000;    // lowROMBase is either cart bank mapped or non-plus Lower ROM if enabled
      else
        readMap[1] = (readMap[0] = addr) + 0x2000;          // Lower ROM not enabled
    }
  
    // Map region #4000..#7fff
    addr = asicRAM ? baseAddr[BASE_ASIC] : baseRAM[1];      // Use ASIC RAM or normal RAM
    writeMap[3] = (writeMap[2] = addr) + 0x2000;
    if (currLow == 0x08)                                    // Secondary ROM mapping to #4000
      readMap[3] = (readMap[2] = lowROMBase) + 0x2000;
    else
      readMap[3] = (readMap[2] = addr) + 0x2000;            // RAM at #4000

    // Map region #8000..#bfff
    addr = baseRAM[2];
    writeMap[5] = (writeMap[4] = addr) + 0x2000;            // #8000 always maps to write RAM
    if (currLow == 0x10)                                    // Secondary ROM mapping to #8000
      readMap[5] = (readMap[4] = lowROMBase) + 0x2000;
    else
      readMap[5] = (readMap[4] = addr) + 0x2000;            // RAM at #8000

    // Map region #c000..#ffff
    addr = baseRAM[3];
    writeMap[7] = (writeMap[6] = addr) + 0x2000;
    if (upper && upROMBase != -1)
      readMap[7] = (readMap[6] = upROMBase) + 0x2000;
    else
      readMap[7] = (readMap[6] = addr) + 0x2000;

  }

  @Override
  public void writePort(int port, int value) {
    setUpperROM(value & 0x0f);
  }

  @Override
  public int readByte(int address, Object config) {
    return readByte(address);
  }

  // CPC Plus Secondary ROM Mapping
  public void mapSecondaryROM(int out) {
    // If ASIC Unlocked
    // srmr = out
    cartLowBase = (out & 0x07) << 14;  // * 16K
    int addr = (cartLowBase == 0 && lowerROMInserted) ? baseAddr[BASE_LOWROM] :
      baseAddr[BASE_CART] + cartLowBase;
    lowROM = out & 0x18;                                     // Secondary Mapping
    asicRAM = lowROM == 0x18;                                // ASIC RAM enabled?
    if (asicRAM)
      lowROM = 0x00;                                         // Same as Mapping 0x00 but with ASIC RAM
    lowROMBase = cartEnabled ? addr : baseAddr[BASE_LOWROM];
    currLow = lower && lowROMBase != -1 ? lowROM : 0xff;     // CurrLow only set if Lower ROM enabled!
    remap();
  }
 
}