package jemu.core.device.storage;

/**
 * A file on a FileSystem
 *
 * @author Richard Wilson
 */
public class FSFile  {
	
	protected FileSystem fs;
	protected FSFile parent;  // Parent Directory
	protected String name;
	protected int attributes;
	protected long size;
	protected long created;
	protected long modified;
	
}
