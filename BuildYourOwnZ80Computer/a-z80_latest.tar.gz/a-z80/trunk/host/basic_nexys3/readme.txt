Target board: Nexys3 Digilent Xilinx Spartan-6 Development Board

This folder contains a simple "basic" board computer with the A-Z80,
some RAM and UART which can run selected Z80 executable files.

Connect UART at 115200 baud to see the output.

./tools/zmac contains few Z80 sample programs to run and batch scripts
to assemble and copy them into this directory.
