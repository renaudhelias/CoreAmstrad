package jemu.system.c64;

import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import jemu.core.*;
import jemu.core.cpu.*;
import jemu.core.device.*;
import jemu.core.device.crtc.*;
import jemu.core.device.memory.*;
import jemu.core.device.io.*;
import jemu.core.device.sound.*;
import jemu.ui.*;
import jemu.util.diss.*;

/**
 * Title:        JEMU
 * Description:  The Java Emulation Platform
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author
 * @version 1.0
 */

public class C64 extends Computer {

  protected static final int CYCLES_PER_SECOND = 985248;
  protected static final int AUDIO_TEST        = 0x40000000;
  
  protected static final int FRAME_EVENT       = 0;
  protected static final int BA_LOW_EVENT      = 1;
  protected static final int BA_HIGH_EVENT     = 2;
  
  protected MC6502 cpu = new MC6502(CYCLES_PER_SECOND);
  protected C64Memory memory = new C64Memory();
  protected VICII vic = (VICII)addDevice(new VICII(this,FRAME_EVENT));
  protected M6526 cia1 = (M6526)addDevice(new M6526(),"CIA 1");
  protected M6526 cia2 = (M6526)addDevice(new M6526(),"CIA 2");
  protected Keyboard keyboard = new Keyboard();
  protected Disassembler disassembler = new Diss6502();
  protected int audioAdd = 0; //psg.getSoundPlayer().getClockAdder(AUDIO_TEST,CYCLES_PER_SECOND);
  protected int audioCount = 0;

  public C64(Applet applet, String name) {
    super(applet,name);
    cpu.setMemoryDevice(this);
    cpu.setCycleDevice(this);
    vic.setEventDevice(this, BA_LOW_EVENT, BA_HIGH_EVENT);
    vic.setInterruptDevice(cpu, 0x01);
    cia1.setInterruptDevice(cpu, 0x02);
    cia2.setInterruptDevice(this, 0x01);  // TODO: Wire the NMI
    cia1.getPort(M6526.PORT_A).setOutputDevice(keyboard,0);
    cia1.getPort(M6526.PORT_B).setInputDevice(keyboard,0);
    //psg.setClockSpeed(CYCLES_PER_SECOND);
    //psg.getSoundPlayer().play();
    setBasePath("c64");
  }

  public void initialise() {
    memory.loadROM(C64Memory.ROM_BASIC,getFile(romPath + "BASIC.ROM",0x2000));
    memory.loadROM(C64Memory.ROM_KERNAL,getFile(romPath + "KERNAL.ROM",0x2000));
    memory.loadROM(C64Memory.ROM_CHAR,getFile(romPath + "CHAR.ROM",0x1000));
    vic.setMemory(memory.getMemory());
    super.initialise();
  }
  
  public void cycle() {
    vic.cycle();
    cia1.cycle();
    cia2.cycle();
    if ((audioCount += audioAdd) >= AUDIO_TEST) {
      //psg.writeAudio();
      audioCount -= AUDIO_TEST;
    }
  }

  public void setDisplay(Display value) {
    super.setDisplay(value);
    vic.setDisplay(value);
  }

  public void setFrameSkip(int value) {
    super.setFrameSkip(value);
    //vic.setRendering(value == 0);
  }

  public int event(int id) {
    if (id == FRAME_EVENT) {
      if (frameSkip == 0)
        display.updateImage(true);
      syncProcessor();
    }
    else
      cpu.setReady(id == BA_HIGH_EVENT);
    return 0;
  }

  public Memory getMemory() {
    return memory;
  }

  public Processor getProcessor() {
    return cpu;
  }

  public Dimension getDisplaySize(boolean large) {
    return vic.getDisplaySize(large);
  }
  
  public Dimension getDisplayScale(boolean large) {
    return large ? Display.SCALE_2 : Display.SCALE_1;
  }
  
  public Disassembler getDisassembler() {
    return disassembler;
  }

  public int readByte(int address) {
    if (address <= 0x01) {
      return address == 0 ? ddrMask ^ 0xff : romEnable;
    }
    else if (ioEnable && address >= 0xd000 && address < 0xe000) {
      // IO Read
      switch(address & 0x0c00) {
        case 0x0000: return vic.readPort(address);
        case 0x0400: return 0xff;  // SID
        case 0x0800: return vic.readByte(address & 0x3ff);
        default: {
          if ((address & 0x300) == 0)
            return cia1.readPort(address);
          else
            return 0xff;  // Other peripheral devices (CIA, User etc).
        }
      }
    }
    else
      return memory.readByte(address);
  }
  
  protected int ddrMask = 0x00;
  protected int romEnable = 0x2f;
  protected boolean ioEnable = true;
  
  public void reset() {
    ddrMask = 0x00;
    setROMEnable(0xff);
    super.reset();
  }
  
  protected void setROMEnable(int value) {
    romEnable = value;  // TODO - Is this correct (or does it set value | ddrMask
    int enable = value | ddrMask; 
    memory.setROMEnable(enable);
    ioEnable = (value & 0x03) != 0 && (value & 0x04) != 0;
  }

  public int writeByte(int address, int value) {
    if (address <= 0x01) {
      if (address == 0x00) {
        ddrMask = value ^ 0xff;
        setROMEnable(romEnable);
      }
      else
        setROMEnable(value);
      return value & 0xff;
    }
    else if (ioEnable && address >= 0xd000 && address < 0xe000) {
      // IO Write
      switch(address & 0x0c00) {
        case 0x0000: vic.writePort(address,value); break;
        case 0x0400: ; break;  // SID
        case 0x0800: return vic.writeByte(address,value);
        default: {
          if ((address & 0x300) == 0)
            cia1.writePort(address,value);
          break; // CIA's, User Ports
        }
      }
      return value & 0xff;
    }
    else
      return memory.writeByte(address,value);
  }

  public void keyPressed(KeyEvent e) {
    keyboard.keyPressed(e.getKeyCode(),e.getKeyLocation());
  }
  
  public void keyReleased(KeyEvent e) {
    keyboard.keyReleased(e.getKeyCode(),e.getKeyLocation());    
  }
  
  public static final String VSF_HEADER  = "VICE Snapshot File\032";
  public static final String MACHINE_C64 = "C64";
  
  public static final String MAINCPU     = "MAINCPU";
  public static final String C64MEM      = "C64MEM";
  public static final String CIA1        = "CIA1";
  public static final String CIA2        = "CIA2";
  public static final String SID         = "SID";
  public static final String VIC_II      = "VIC-II";
  
  protected void setCIA(InputStream in, M6526 cia, int size) throws Exception {
    byte[] data = new byte[0x2b];
    readStream(in, data, 0, 0x2b);
    IOPort porta = cia.getPort(M6526.PORT_A);
    IOPort portb = cia.getPort(M6526.PORT_B);
    porta.setOutput(data[0x00] & 0xff);
    portb.setOutput(data[0x01] & 0xff);
    porta.setPortMode(data[0x02] & 0xff);
    portb.setPortMode(data[0x03] & 0xff);
    cia.setCountA(getWord(data, 0x04));
    cia.setCountB(getWord(data, 0x06));
    cia.setTimeOfDay(data[0x0b], data[0x0a], data[0x09], data[0x08]);
    cia.writePort(0x0c, data[0x0c] & 0xff);   // SDR
    cia.setEnabledInterrupts(data[0x0d]);
    cia.setCRA(data[0x0e]);
    cia.setCRB(data[0x0f]);
    cia.setLatchA(getWord(data, 0x10));
    cia.setLatchB(getWord(data, 0x12));
    cia.setActiveInterrupts(data[0x14]);
    // TODO: PB6/7 bits toggle state and 2/3 port state [0x15]
    // TODO: SDR bits to shift [0x16]
    cia.setAlarm(data[0x1a], data[0x19], data[0x18], data[0x17]);
    // TODO: Current clock - clock when ICR was last read????? (todTick!) [0x1b]
    cia.setTimeOfDayStopped((data[0x1c] & 0x02) != 0);
    if ((data[0x1c] & 0x01) == 0)
      cia.clearTimeLatch();
    else
      cia.setTimeLatch(data[0x20], data[0x1f], data[0x1e], data[0x1d]);
    cia.setTimeOfDayTicks(data[0x21]);  // This is a DWord
    // TODO: Ignore TASTATE and TBSTATE from VSF??? [0x25], [0x27]
    skipStream(in, size - 0x2b);
  }
  
  @Override
  public void loadFile(int type, String name) throws Exception {
    InputStream in = openFile(name);
    try {
      byte[] header = new byte[0x25];
      readStream(in, header, 0, 0x25, false);
      if (!VSF_HEADER.equals(new String(header,0,VSF_HEADER.length())))
        throw new Exception("Unknown file type");
      int end = 0x25;
      while (end > 0x15 && header[end - 1] == 0) end--;
      String machine = new String(header, 0x15, end - 0x15);
      if (!MACHINE_C64.equals(machine))
        throw new Exception("Unknown Machine type: " + machine);
      
      // Need MAINCPU, C64MEM at least
      boolean mainCPU = false;
      boolean c64Mem = false;
      
      do {
        end = readStream(in, header, 0, 0x16, false);
        if (end == 0x16) {
          System.out.println("header: " + new String(header, 0, 0x10).trim());
          int size = getDWord(header, 0x12) - 0x16;
          String block = new String(header, 0, 0x10).trim();
          if (MAINCPU.equals(block)) {
            mainCPU = true;
            readStream(in, header, 0, 0x1f);
            cpu.setA(header[0x04]);
            cpu.setX(header[0x05]);
            cpu.setY(header[0x06]);
            cpu.setS(header[0x07]);
            cpu.setPC(getWord(header, 0x08));
            cpu.setStatus(header[0x0a]);
            skipStream(in, size - 0x1f);
          }
          else if (C64MEM.equals(block)) {
            c64Mem = true;
            readStream(in, header, 0, 4);
            byte[] mem = new byte[0x10000];
            readStream(in, mem, 0, 0x10000);
            for (int addr = 0; addr < 0x10000; addr++)
              memory.writeByte(addr, mem[addr]);
            writeByte(0, header[1]);
            writeByte(1, header[0]);
            skipStream(in, size - 0x10004);
          }
          else if (CIA1.equals(block))
            setCIA(in, cia1, size);
          else if (CIA2.equals(block))
            setCIA(in, cia2, size);
          else if (VIC_II.equals(block)) {
            byte[] regs = new byte[0x4c7];
            readStream(in, regs, 0, 0x4c7);
            // Allow bad lines [0x00] - not used
            vic.setBadLine(regs[0x01] != 0);
            vic.setBorder(regs[0x02] != 0);
            vic.setPaletteData(regs, 0x03);
            vic.setPaletteRAM(regs, 0x2b);
            // TODO: Idle state! [0x42b]
            // TODO: Light pen trigger [0x42c]
            // TODO: Light Pen X, Y [0x42d/e]
            vic.setCharacterData(regs, 0x42f);
            // TODO: New Sprite DMA Mask [0x457]
            // TODO: Screen base? Or is this in the registers?
            vic.setCycle(regs[0x45c]);
            vic.setRaster(getWord(regs, 0x45d));
            for (int i = 0; i < 0x40; i++)
              if (i != 0x19)
                vic.writePort(i, regs[0x45f + i] & 0xff);
            vic.setInterruptRegister(regs[0x45f + 0x019]);
            // TODO: Sprite collision [0x49f], DMA [0x4a0], Sprite-Sprite Collision [0x4a1]
            vic.setBank(getWord(regs, 0x4a2));
            // TODO: VCBase etc, IRQ state
            skipStream(in, size - 0x4c7);
          }
          else
            skipStream(in, size);
        }
      } while (end == 0x16);
    } finally {
      in.close();
    }
  }

  public void displayLostFocus() {
    keyboard.reset();
  }

}