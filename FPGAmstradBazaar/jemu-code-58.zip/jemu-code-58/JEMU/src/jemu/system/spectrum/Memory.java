package jemu.system.spectrum;

import jemu.core.device.memory.*;

/**
 * Emulated the ZX Spectrum ROM and RAM Memory.
 *
 * @author Richard Wilson
 */
public class Memory extends DynamicMemory {
  
  public static final int ROM = 0;
  public static final int RAM = 1;
  
  /** Creates a new instance of Memory */
  public Memory() {
    super("ZX Spectrum Memory",0x10000,2);
    getMem(ROM,0x4000);
    getMem(RAM,0xc000);
  }
  
  public int readByte(int addr) {
    return mem[addr] & 0xff;
  }
  
  public int writeByte(int addr, int value) {
    if (addr >= 0x4000)
      mem[addr] = (byte)value;
    return value & 0xff;
  }
  
  public void setROM(byte[] data) {
    System.arraycopy(data,0,mem,0,Math.min(data.length,0x4000));
  }
}
