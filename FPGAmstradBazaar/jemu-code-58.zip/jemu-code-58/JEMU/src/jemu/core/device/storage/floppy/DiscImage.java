package jemu.core.device.storage.floppy;

import jemu.core.device.storage.*;

/**
 * Provides an abstract Disc Image class. With some ability to get/set sector information for
 * each cylinder and head.
 *
 * @author Richard Wilson
 */
public abstract class DiscImage implements SectorDevice {
  
  protected String name;
  
  public DiscImage(String name) {
    this.name = name;
  }
  
  public String getName() {
    return name;
  }
  
}
