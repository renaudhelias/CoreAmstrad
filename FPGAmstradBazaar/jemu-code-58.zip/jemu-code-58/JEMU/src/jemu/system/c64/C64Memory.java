package jemu.system.c64;

import jemu.core.device.memory.*;

/**
 * Emulates Commodore 64 Memory.
 *
 * @author Richard Wilson
 */
public class C64Memory extends Memory {
  
  public static final int ROM_CHAR   = 0x10000;
  public static final int ROM_BASIC  = 0x11000;
  public static final int ROM_KERNAL = 0x13000;
  
  // Split into 16 4K banks plus 3 for ROMs
  protected int[] readMap = new int[16];
  
  protected byte[] mem = new byte[0x15000];
   
  /** Creates a new instance of C64Memory */
  public C64Memory() {
    super("C64 Memory",0x10000);
    for (int i = 0; i < 16; i++)
      readMap[i] = 0;
    setROMEnable(0x0f);
  }
  
  public int readByte(int address) {
    return mem[readMap[address >> 12] + address] & 0xff;
  }
  
  public int writeByte(int address, int value) {
    return (mem[address] = (byte)value) & 0xff;
  }
  
  public void setROMEnable(int value) {
    readMap[0x0a] = readMap[0x0b] = (value & 0x03) == 3 ? ROM_BASIC - 0xa000 : 0;
    readMap[0x0e] = readMap[0x0f] = (value & 0x02) != 0 ? ROM_KERNAL - 0xe000 : 0;
    readMap[0x0d] = (value & 0x03) != 0 && (value & 0x04) == 0 ? ROM_CHAR - 0xd000 : 0;
  }
  
  public void loadROM(int rom, byte[] data) {
    System.arraycopy(data, 0, mem, rom, data.length);
  }
  
  public byte[] getMemory() {
    return mem;
  }
  
}
