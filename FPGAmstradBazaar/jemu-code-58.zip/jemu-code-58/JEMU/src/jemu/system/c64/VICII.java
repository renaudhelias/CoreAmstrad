package jemu.system.c64;

import java.awt.*;
import jemu.core.device.*;
import jemu.core.renderer.*;

/**
 * Emulates the Commodore VIC II chip and renders pixels.
 *
 * @author Richard Wilson
 */
public class VICII extends Renderer {
  
  public static final int[] RGB_VALUES = {
    0x000000, 0xFFFFFF, 0x68372B, 0x70A4B2,
    0x6F3D86, 0x588D43, 0x352879, 0xB8C76F,
    0x6F4F25, 0x433900, 0x9A6759, 0x444444,
    0x6C6C6C, 0x9AD284, 0x6C5EB5, 0x959595
  };
  
  // Registers
  public static final int M0X      = 0x00;
  public static final int M0Y      = 0x01;
  public static final int M1X      = 0x02;
  public static final int M1Y      = 0x03;
  public static final int M2X      = 0x04;
  public static final int M2Y      = 0x05;
  public static final int M3X      = 0x06;
  public static final int M3Y      = 0x07;
  public static final int M4X      = 0x08;
  public static final int M4Y      = 0x09;
  public static final int M5X      = 0x0a;
  public static final int M5Y      = 0x0b;
  public static final int M6X      = 0x0c;
  public static final int M6Y      = 0x0d;
  public static final int M7X      = 0x0e;
  public static final int M7Y      = 0x0f;
  public static final int MXMSB    = 0x10;
  public static final int CONTROL1 = 0x11;
  public static final int RASTER   = 0x12;
  public static final int LPX      = 0x13;
  public static final int LPY      = 0x14;
  public static final int MENABLE  = 0x15;
  public static final int CONTROL2 = 0x16;
  public static final int MYEXP    = 0x17;
  public static final int MEMPTR   = 0x18;
  public static final int INT      = 0x19;
  public static final int IENABLE  = 0x1a;
  public static final int MPRTY    = 0x1b;
  public static final int MMC      = 0x1c;
  public static final int MXEXP    = 0x1d;
  public static final int MMCOLL   = 0x1e;
  public static final int MDCOLL   = 0x1f;
  public static final int EC       = 0x20;
  public static final int B0C      = 0x21;
  public static final int B1C      = 0x22;
  public static final int B2C      = 0x23;
  public static final int B3C      = 0x24;
  public static final int MM0      = 0x25;
  public static final int MM1      = 0x26;
  public static final int M0C      = 0x27;
  public static final int M1C      = 0x28;
  public static final int M2C      = 0x29;
  public static final int M3C      = 0x2a;
  public static final int M4C      = 0x2b;
  public static final int M5C      = 0x2c;
  public static final int M6C      = 0x2d;
  public static final int M7C      = 0x2e;
  
  public static final int INT_RASTER = 0x01;
  
  protected static final int[] REG_MASKS = new int[] {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     // 00..07
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     // 08..0F
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xc0, 0x00,     // 10..17
    0x01, 0x70, 0xf0, 0x00, 0x00, 0x00, 0x00, 0x00,     // 18..1F
    0xf0, 0xf0, 0xf0, 0xf0, 0xf0, 0xf0, 0xf0, 0xf0,     // 20..27
    0xf0, 0xf0, 0xf0, 0xf0, 0xf0, 0xf0, 0xf0, 0xf0,     // 28..2F
    0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,     // 30..37
    0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,     // 38..3F
  };
   
  protected static int[] ADDR_XLATE = new int[0x10000];
  static {   
    // Address translation
    for (int i = 0; i < 0x10000; i++)
      ADDR_XLATE[i] = (i & 0x7000) == 0x1000 ? 0x10000 | (i & 0xfff) : i;
  };
  
  // May need 9 to cover idle state (but might not need one for MC text and invalid, share others???)
  protected static byte[][][] MODE_MAPS = new byte[8][256][8];  // Pixel colour indices
  protected static int[][] MODE_COLL = new int[8][256];       // Bits for collision
  static {
    for (int i = 0; i < 256; i++) {
      MODE_COLL[0][i] = i;
      for (int pix = 0; pix < 8; pix++) {
        MODE_MAPS[0][i][pix] = (byte)((i >> (7 - pix)) & 0x01);
        MODE_MAPS[3][i][pix] = (byte)((i >> (6 - (pix & 0x06))) & 0x03);  // TODO: Fix this
      }
    }
    MODE_MAPS[1] = MODE_MAPS[0];
    MODE_MAPS[2] = MODE_MAPS[0];
  };
  
  // Only doing PAL at the moment
  public static final int CYCLES_PER_LINE = 63;
  public static final int LINES_PER_FRAME = 312;
  public static final int FIRST_DISP_LINE = 16;
  public static final int LAST_DISP_LINE  = 288;  // + 1
  
  public static final Dimension DISPLAY_SIZE = new Dimension(384,LAST_DISP_LINE - FIRST_DISP_LINE);
  
  protected byte[] mem;
  protected int[] pmem = new int[0x400];
  
  protected int[] regs = new int[0x40];
  
  // Palettes for each mode
  protected int[][] palettes = new int[][] {
    { 0, 1, 2, 3 }, { 0, 1, 2, 3 }, { 0, 1, 2, 3 }, { 0, 1, 2, 3 },
    { 0, 1, 2, 3 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 }
  };
  
  protected Sprite[] sprite = new Sprite[8];  // Sprites
  protected int mode;                         // Current screen mode
  protected int yscrl;                        // Y Scroll
  protected int xscrl;                        // X Scroll
  protected boolean den;                      // Display Enable
  protected boolean csel;                     // Columns Select
  protected boolean rsel;                     // Rows Select
  protected int rasterInt = 0;                // Raster Interrupt row
  protected int borderPixel;                  // Border Pixel Colour
  protected int vBorderStart = 251;           // Vertical Border Start line
  protected int vBorderEnd   = 51;            // Vertical Border End line
  protected int hBorderStart = 55;            // Horizontal Border End
  protected Device interruptDevice;           // Device to interrupt
  protected int interruptMask;                // The Mask for the interrupt
  protected Device eventDevice;               // Device to listen for BA changes
  protected int baLowEvent;                   // Event code for BA going low (active)
  protected int baHighEvent;                  // Event code for BA going high
  
  protected Computer computer;                // Notified by event() method
  protected int frameEvent;                   // Event to send when frame complete
  protected int offset = 0;                   // Offset in bitmap data
  protected int raster = 0;                   // Current Raster
  protected int cycle = 0;                    // Current cycle within the raster
  protected int base;                         // Full base address for VCBASE etc VCn and bank
  protected int textBase;                     // Full base address for text mode CBn and bank
  protected int gfxBase;                      // Full base address for graphics mode CB13 and bank
  protected boolean vBorder = true;           // Vertical Border Flip-Flop
  protected boolean border = false;           // Master Border Flip-Flop
  protected int data;                         // Current graphics data read from memory
  protected int nextData;                     // Next graphics data read from memory
  protected int cData;                        // Current character data read from memory
  protected int nextCData;                    // Next character data read from memory
  protected int palData;                      // Current palette data read from memory
  protected int nextPal;                      // Next palette data read from memory
  protected int nextAddrText;                 // Next text address
  protected int nextAddrGfx;                  // Next graphics address
  protected int nextAddrECM;                  // Next ECM mode address
  protected int[] cdata = new int[40];        // Current character pointer data
  protected int[] pdata = new int[40];        // Palette data for line fetched in bad line
  protected int vmli;                         // Character data offset
  protected int vc;                           // Current address
  protected int vcbase;                       // Current base address
  protected int rc;                           // Row Counter
  protected boolean badLine;                  // Bad Line?
  protected int idleAddr = 0x3fff;            // Address to read when idle
  protected byte[][] modeMap;                 // Map for current mode
  protected byte[][] modeMapMC;               // Another map for MC Text mode
  protected int[] pal;                        // Current Palette
  protected byte[] pixelMap;                  // Current set of 8 pixels
  protected boolean displaying;               // Display started (or idle?)
  protected boolean ba;                       // BA line state
  protected int activeSprites;                // Currently ative sprites
  
  protected NullRenderer       rendNull       = new NullRenderer();
  protected BorderRenderer     rendBorder     = new BorderRenderer();
  protected TextRenderer       rendText       = new TextRenderer();
  protected MCTextRenderer     rendMCText     = new MCTextRenderer();
  protected GraphicsRenderer   rendGfx        = new GraphicsRenderer();
  protected MCGraphicsRenderer rendMCGfx      = new MCGraphicsRenderer();
  
  protected CycleRenderer      renderer       = rendNull;
  protected CycleRenderer      normalRenderer = rendText;
  
  protected DataFetcher[]      line0Fetch     = new DataFetcher[CYCLES_PER_LINE];
  protected DataFetcher[]      nullFetch      = new DataFetcher[CYCLES_PER_LINE];
  protected DataFetcher[]      idleFetch      = new DataFetcher[CYCLES_PER_LINE];
  protected DataFetcher[]      displayFetch   = new DataFetcher[CYCLES_PER_LINE];
  protected DataFetcher[]      badLineFetch   = new DataFetcher[CYCLES_PER_LINE];
  protected DataFetcher[][]    allFetchers    = { line0Fetch, nullFetch, idleFetch, displayFetch, badLineFetch };
  
  protected DataFetcher[]      fetcher        = line0Fetch;
  
  // Modes are:
  // 000 - Standard Text
  // 001 - Multicolor Text
  // 010 - Standard Bitmap
  // 011 - Multicolor Bitmap
  // 100 - ECM Text Mode
  // 101 - Invalid Text Mode
  // 110 - Invalid Bitmap mode 1
  // 111 - Invalid Bitmap mode 2
  
  /** Creates a new instance of VICII */
  public VICII(Computer computer, int frameEvent) {
    super("VIC II");
    this.computer = computer;
    this.frameEvent = frameEvent;
    // Initialise sprites
    for (int i = 0; i < 8; i++)
      sprite[i] = new Sprite();
    
    // Initialise all to idle data fetchers
    int last = allFetchers.length - 1;
    NullFetcher fn = new NullFetcher();
    IdleFetcher fi = new IdleFetcher();
    for (int i = 0; i < CYCLES_PER_LINE; i++) {
      setFetchers(i, 0, 1, fn);
      setFetchers(i, 2, last, fi);
    }
    DisplayFetcher fd = new DisplayFetcher();
    BadLineFetcher fb = new BadLineFetcher();
    for (int i = 16; i < 54; i++) {
      displayFetch[i] = fd;
      badLineFetch[i] = fb;
    }
    
    // Set up Sprite DataFetchers
    int index = CYCLES_PER_LINE - 6;
    for (int i = 0; i < 8; i++) {
      SpriteFetcher0 fs0 = new SpriteFetcher0();
      SpriteFetcher1 fs1 = new SpriteFetcher1();
      fs0.sprite = fs1.sprite = i;
      fs0.baMask = (1 << (i + 2)) & 0xff;
      fs1.baMask = (3 << (i + 1)) & 0xff;
      setFetchers(index++, 0, last, fs0);
      setFetchers(index, 0, last, fs1);
      index = index == CYCLES_PER_LINE - 1 ? 0 : index + 1;
    }

    setFetchers(0, 1, last, new Cycle0Fetcher());
    line0Fetch[1] = new Line0Cycle1Fetcher();
    setFetchers(11, 2, last, new Cycle11Fetcher());
    setFetchers(15, 2, last, new Cycle15Fetcher());
    idleFetch[54] = new Cycle54Fetcher(idleFetch[53]);
    displayFetch[54] = new Cycle54Fetcher(displayFetch[53]);
    badLineFetch[54] = new Cycle54Fetcher(badLineFetch[53]);
    setFetchers(55, 2, last, new Cycle55Fetcher());
    setFetchers(58, 2, last, new Cycle58Fetcher());  // Not the same for NTSC!
    setFetchers(59, 2, last, new Cycle59Fetcher());  // Not the same for NTSC!
    setFetchers(CYCLES_PER_LINE - 1, 0, last, new LastCycleFetcher());
    reset();
  }
  
  protected void setFetchers(int index, int start, int end, DataFetcher fetcher) {
    for (int i = start; i <= end; i++)
      allFetchers[i][index] = fetcher;
  }
  
  @Override
  public void reset() {
    super.reset();
    for (int i = 0; i < regs.length; i++)
      regs[i] = 0;
    borderPixel = 0;
    cycle = raster = offset = rasterInt = 0;
    renderer = rendNull;
    mode = 1; // So mode change occurs
    setMode(0);   
  }
  
  public void setInterruptDevice(Device device, int mask) {
    interruptDevice = device;
    interruptMask = mask;
  }
  
  public void setEventDevice(Device device, int baLow, int baHigh) {
    eventDevice = device;
    baLowEvent = baLow;
    baHighEvent = baHigh;
  }
  
  public Dimension getDisplaySize(boolean large) {
    return DISPLAY_SIZE;
  }
  
  public void setMemory(byte[] value) {
    mem = value;
  }
  
  // Sets the upper address lines, can be 0x0000, 0x4000, 0x8000 or 0xc000
  public void setBank(int value) {
    value &= 0xc000;
    base = (base & 0x3fff) | value;
    textBase = (textBase & 0x3fff) | value;
    gfxBase = textBase & 0xe000;
    idleAddr = (idleAddr & 0x3fff) | value;
  }
   
  protected void setSpriteXHi(int value) {
    for (int i = 0; i < 8; i++)
      sprite[i].setXHi(value << (8 - i));
  }
    
  protected void setSpriteEnable(int value) {
    
  }
  
  protected void setSpriteExpandY(int value) {
    
  }
  
  protected void setSpriteExpandX(int value) {
    
  }
  
  protected void setSpritePriority(int value) {
    
  }
  
  protected void setSpriteMulticolor(int value) {
    
  }
  
  @Override
  public final void setInterrupt(int mask) {
    if ((regs[INT] & mask) != mask) {
      regs[INT] |= mask;
      if ((regs[INT] & 0x80) == 0 && (regs[INT] & regs[IENABLE]) != 0) {
        regs[INT] |= 0x80;
        if (interruptDevice != null)
          interruptDevice.setInterrupt(interruptMask);
      }
    }
  }
  
  @Override
  public final void clearInterrupt(int mask) {
    if ((regs[INT] & mask) != 0) {
      regs[INT] &= ~mask;
      if ((regs[INT] & 0x80) != 0 && (regs[INT] & regs[IENABLE]) == 0) {
        regs[INT] &= 0x7f;
        if (interruptDevice != null)
          interruptDevice.clearInterrupt(interruptMask);
      }
    }
  }
  
  protected void setMode(int value) {
    if (mode != value) {
      modeMap = MODE_MAPS[mode = value];
      if (mode == 1)
        modeMapMC = MODE_MAPS[3];
      else if (mode == 5)
        modeMapMC = MODE_MAPS[7];
      pal = palettes[mode];
      if ((mode & 0x04) != 0)
        idleAddr &= 0xf9ff;
      else
        idleAddr |= 0x3fff;
      boolean update = renderer == normalRenderer;
      switch(mode) {
        case 0: normalRenderer = rendText;   break;
        case 1: normalRenderer = rendMCText; break;
        case 2: normalRenderer = rendGfx;    break;
        case 3: normalRenderer = rendMCGfx;  break;
      }
      if (update)
        renderer = normalRenderer;
    }
  }
    
  @Override
  public void writePort(int port, int value) {
    port &= 0x3f;
    if (port != 0x19)
      regs[port] = value = value & ~REG_MASKS[port];
    if (port < 0x10) {
      if ((port & 0x01) == 0)
        sprite[port >> 1].setXLo(value);
      else
        sprite[port >> 1].y = value;
    }
    else
      switch(port) {
        case 0x10: setSpriteXHi(value); break;
        
        case 0x11: {
          setMode((mode & 0x01) | ((value & 0x60) >> 4));
          yscrl = value & 0x07;
          if (rsel != ((value & 0x08) != 0)) {
            if (rsel) {
              rsel = false;
              vBorderStart = 247;
              vBorderEnd = 55;
            }
            else {
              rsel = true;
              vBorderStart = 251;
              vBorderEnd = 51;
            }
          }
          rasterInt = (rasterInt & 0xff) | ((value & 0x80) << 1);
          break;
        }
        
        case 0x12: rasterInt = (rasterInt & 0x100) | value; break; // Set Raster Interrupt
        
        case 0x15: setSpriteEnable(value); break;
        
        case 0x16: {
          setMode((mode & 0x06) | ((value & 0x10) >> 4));
          xscrl = value & 0x07;
          break;
        }
        
        case 0x17: setSpriteExpandY(value); break;
        
        case 0x18: {
          base = (base & 0xc000) | ((value & 0xf0) << 6);
          textBase = (textBase & 0xc000) | ((value & 0x0e) << 10);
          gfxBase = textBase & 0xe000;
          break; // Memory Pointers
        }
        
        case 0x19: clearInterrupt(value & 0x0f); break;
        
        case 0x1a: {
          regs[INT] = regs[INT] & ~value;
          if ((regs[INT] & 0x80) == 0) {
            if ((regs[INT] & regs[IENABLE]) != 0) {
              regs[INT] |= 0x80;
              if (interruptDevice != null)
                interruptDevice.setInterrupt(interruptMask);
            }
          }
          else if ((regs[INT] & regs[IENABLE]) == 0) {
            regs[INT] &= 0x7f;
            if (interruptDevice != null)
              interruptDevice.clearInterrupt(interruptMask);
          }
          break;
        }
        
        case 0x1b: setSpritePriority(value); break;
        
        case 0x1c: setSpriteMulticolor(value); break;
        
        case 0x1d: setSpriteExpandX(value); break;
        
        case 0x20: borderPixel = RGB_VALUES[value & 0x0f]; break;
        
        case 0x21: palettes[0][0] = palettes[1][0] = palettes[3][0] =
          palettes[4][0] = (byte)(value & 0x0f); break;
          
      }
  }
  
  public int readPort(int port) {
    port &= 0x3f;
    if (port == 0x11)
      return regs[0x11] & 0x7f | (raster == 0 && cycle == 0 ? 0x80 : (raster >> 1) & 0x80);
    else if (port == 0x12)
      return (raster == 0 && cycle == 0 ? LINES_PER_FRAME - 1 : raster) & 0xff;
    return regs[port] | REG_MASKS[port];
  }
  
  public int writeByte(int address, int value) {
    pmem[address & 0x3ff] = value & 0x0f;
    return value & 0xff;
  }
  
  public int readByte(int address) {
    return pmem[address & 0x3ff];
  }
  
  public void cycle() {
    renderer.render();
    fetcher[cycle].fetch();
  }
  
  protected void setBA() {
    ba = true;
    if (eventDevice != null)
      eventDevice.event(baLowEvent);
  }
  
  protected void clearBA() {
    ba = false;
    if (eventDevice != null)
      eventDevice.event(baHighEvent);
  }
  
  public void setBadLine(boolean value) {
    badLine = value;
  }

  public void setBorder(boolean value) {
    border = value;
  }
  
  public void setCharacterData(byte[] source, int offset) {
    for (int i = 0; i < 40; i++)
      cdata[i] = source[offset + i] << 3; // TODO: Different for other modes
  }
  
  public void setPaletteData(byte[] source, int offset) {
    for (int i = 0; i < 40; i++)
      pdata[i] = source[offset + i] & 0xff;
  }
  
  public void setPaletteRAM(byte[] source, int offset) {
    for (int i = 0; i < 0x400; i++)
      pmem[i] = source[offset + i] & 0x0f;
  }
  
  public void setCycle(int value) {
    cycle = value & 0xff;
  }
  
  public void setRaster(int value) {
    raster = value & 0xffff;
  }
  
  public void setInterruptRegister(int value) {
    clearInterrupt(0xff);
    setInterrupt(value & 0xff);
  }
  
  protected class Sprite {
    int x;
    int y;
    int mask;
    
    protected void setXLo(int value) {
      x = (x & 0x100) | value;
    }
    
    protected void setXHi(int value) {
      x = (x & 0xff) | (value & 0x100);
    }
    
  }
  
  protected abstract class DataFetcher {
    public abstract void fetch();
  }
  
  protected class NullFetcher extends DataFetcher {
    public final void fetch() { cycle++; }
  }
  
  protected class IdleFetcher extends DataFetcher {
    public final void fetch() {
      nextPal = 0;
      nextData = mem[idleAddr] & 0xff;
      cycle++;
    }
  }
  
  protected class Cycle0Fetcher extends DataFetcher {       // Also Sprite0Fetcher for Sprite 3
    public final void fetch() {
      if (rasterInt == raster)
        setInterrupt(INT_RASTER);
      // If Sprite 5 active BA low
      if (!ba && (activeSprites & 0x20) != 0) setBA();
      cycle++;
    }
  }
  
  protected class Line0Cycle1Fetcher extends DataFetcher {  // Also Sprite1Fetcher for Sprite 3
    public final void fetch() {
      if (rasterInt == (raster = vc = vcbase = 0))
        setInterrupt(0x01);
      if (ba && (activeSprites & 0x30) == 0) clearBA();
      cycle++;
    }
  }
  
  protected class LastCycleFetcher extends DataFetcher {  // Also Sprite1Fetcher for Sprite 2
    public final void fetch() {
      if (raster != LINES_PER_FRAME - 1) {
        if (++raster == vBorderStart)
          border = vBorder = true;
        else if (raster == vBorderEnd)
          vBorder = false;
        if (raster < FIRST_DISP_LINE || raster >= LAST_DISP_LINE)
          fetcher = nullFetch;
        else if (raster == FIRST_DISP_LINE)
          fetcher = idleFetch;
        else {
          fetcher = displaying ? displayFetch : idleFetch;
          if (raster >= 0x30 && raster <= 0xf7) {
            if (badLine = (raster & 0x07) == yscrl) {
              rc = 0;
              displaying = true;
              fetcher = badLineFetch;
            }
          }
        }
      }
      else {
        offset = 0;
        computer.event(frameEvent);
        fetcher = line0Fetch;
      }
      if (ba & (activeSprites & 0x18) == 0) clearBA();
      cycle = 0;
    }
  }
  
  protected class SpriteFetcher0 extends DataFetcher {
    
    protected int sprite;
    protected int mask;     // Bit to test for sprite data fetch (maybe fetch always???)
    protected int baMask;   // Which Sprite active to turn BA on
    
    public final void fetch() {
      if (!ba && (activeSprites & baMask) != 0) setBA();
      cycle++;
    }
  }
  
  protected class SpriteFetcher1 extends DataFetcher {
    
    protected int sprite;
    protected int mask;     // Bit to test for sprite data fetch (maybe fetch always???)
    protected int baMask; 
    
    public final void fetch() {
      if (ba && (activeSprites & baMask) == 0) clearBA();
      cycle++;
    }
  }
  
  protected class Cycle11Fetcher extends DataFetcher {
    public final void fetch() {
      if (badLine && !ba) setBA();
      renderer = border ? rendBorder : normalRenderer;
      cycle++;
    }
  }
  
  protected class Cycle15Fetcher extends DataFetcher {
    public final void fetch() {
      if (raster == vBorderStart) vBorder = true;
      else if (raster == vBorderEnd) vBorder = false; // TODO: Only if DEN
      border = vBorder;
      renderer = border ? rendBorder : normalRenderer;
      data = vmli = 0;
      vc = vcbase;
      if (displaying) {
        if (badLine) {
          nextPal = pdata[0] = pmem[vc];
          nextCData = cdata[0] = (mem[ADDR_XLATE[vc | base]] & 0xff) << 3;
        }
        else {
          nextPal = pdata[0];
          nextCData = cdata[0];
        }
        nextAddrText = nextCData | textBase | rc;
        nextAddrGfx = (vc << 3) | gfxBase | rc;
        nextAddrECM = (nextCData & 0x1f8) | gfxBase | rc;
        vmli = 1;
        vc = (vc + 1) & 0x3ff;
      }
      cycle++;
    }
  }
  
  protected class BadLineFetcher extends DataFetcher {
    public final void fetch() {
      nextPal = pdata[vmli] = pmem[vc];
      nextCData = cdata[vmli++] = (mem[ADDR_XLATE[vc | base]] & 0xff) << 3;
      nextAddrText = nextCData | textBase | rc;
      nextAddrGfx = (vc << 3) | gfxBase | rc;
      nextAddrECM = (nextCData & 0x1f8) | gfxBase | rc;
      vc = (vc + 1) & 0x3ff;
      cycle++;
    }
  }
  
  protected class DisplayFetcher extends DataFetcher {
    public final void fetch() {
      nextPal = pdata[vmli];
      nextCData = cdata[vmli++];
      nextAddrText = nextCData | textBase | rc;
      nextAddrGfx = (vc << 3) | gfxBase | rc;
      nextAddrECM = (nextCData & 0x1f8) | gfxBase | rc;
      vc = (vc + 1) & 0x3ff;
      cycle++;
    }
  }
  
  protected class Cycle54Fetcher extends DataFetcher {
    
    protected DataFetcher fetcher;
    
    protected Cycle54Fetcher(DataFetcher fetcher) {
      this.fetcher = fetcher;
    }
    
    public final void fetch() {
      if (hBorderStart == 54) {
        border = true;
        pixels[offset - 1] = borderPixel;
        renderer = rendBorder;
      }
      fetcher.fetch();
    }
  }
  
  protected class Cycle55Fetcher extends DataFetcher {
    public final void fetch() {
      if (hBorderStart == 55) {
        border = true;
        renderer = rendBorder;
      }
      cycle++;
    }
  }
  
  protected class Cycle58Fetcher extends DataFetcher {  // Also Sprite1Fetcher for Sprite 0 PAL
    public final void fetch() {
      if (rc == 7) {
        displaying = false;
        vcbase = vc;
      }
      else if (displaying)
        rc = (rc + 1) & 0x07;
      if (ba && (activeSprites & 0x06) == 0) clearBA();
      cycle++;
    }
  }
  
  protected class Cycle59Fetcher extends DataFetcher {  // Also Sprite0Fetcher for Sprite 1 PAL
    public final void fetch() {
      renderer = rendNull;
      if (!ba && (activeSprites & 0x04) != 0) setBA();
      cycle++;
    }
  }
  
  protected abstract class CycleRenderer {
    public abstract void render();
  }
  
  protected class NullRenderer extends CycleRenderer {
    public final void render() { }
  }
  
  protected class BorderRenderer extends CycleRenderer {
    public final void render() {
      for (int i = 0; i < 8; i++)
        pixels[offset++] = borderPixel;
    }
  }
  
  protected class TextRenderer extends CycleRenderer {
    public final void render() {
      int first = 8 - xscrl;
      if (xscrl != 0) {
        pixelMap = modeMap[data];
        pal[1] = palData;
        for (int i = first; i < 8; i++)
          pixels[offset++] = RGB_VALUES[pal[pixelMap[i]]];
      }
      pixelMap = modeMap[data = mem[ADDR_XLATE[nextAddrText]] & 0xff];
      pal[1] = palData = nextPal;
      for (int i = 0; i < first; i++)
        pixels[offset++] = RGB_VALUES[pal[pixelMap[i]]];
    }
  }
  
  protected class MCTextRenderer extends CycleRenderer {
    public final void render() {
      for (int i = 0; i < 8; i++)
        pixels[offset++] = 0xff0000;
    }
  }
  
  protected class GraphicsRenderer extends CycleRenderer {
    public final void render() {
      int first = 8 - xscrl;
      if (xscrl != 0) {
        pixelMap = modeMap[data];
        pal[0] = (cData >> 3) & 0x0f;
        pal[1]  = cData >> 7;
        for (int i = first; i < 8; i++)
          pixels[offset++] = RGB_VALUES[pal[pixelMap[i]]];
      }
      pixelMap = modeMap[data = mem[ADDR_XLATE[nextAddrGfx]] & 0xff];
      cData = nextCData;
      pal[0] = (cData >> 3) & 0x0f;
      pal[1]  = cData >> 7;
      for (int i = 0; i < first; i++)
        pixels[offset++] = RGB_VALUES[pal[pixelMap[i]]];
    }
  }
  
  protected class MCGraphicsRenderer extends CycleRenderer {
    public final void render() {
      int first = 8 - xscrl;
      if (xscrl != 0) {
        pixelMap = modeMap[data];
        pal[1] = cData >> 7;
        pal[2] = (cData >> 3) & 0x0f;
        pal[3] = palData;
        for (int i = first; i < 8; i++)
          pixels[offset++] = RGB_VALUES[pal[pixelMap[i]]];
      }
      pixelMap = modeMap[data = mem[ADDR_XLATE[nextAddrGfx]] & 0xff];
      cData = nextCData;
      pal[1] = cData >> 7;
      pal[2] = (cData >> 3) & 0x0f;
      pal[3] = palData = nextPal;      
      for (int i = 0; i < first; i++)
        pixels[offset++] = RGB_VALUES[pal[pixelMap[i]]];
    }
  }
  
}
