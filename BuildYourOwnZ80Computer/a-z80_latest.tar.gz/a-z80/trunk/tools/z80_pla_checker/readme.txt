z80_pla_checker
===============
Experiment with a Z80 PLA table! The content of the PLA table is published here:
http://arcfn.com/files/z80-pla-table.html

The master PLA table is in ../resources/z80-pla.txt

Other instruction tables that the tool uses are also in that folder.
