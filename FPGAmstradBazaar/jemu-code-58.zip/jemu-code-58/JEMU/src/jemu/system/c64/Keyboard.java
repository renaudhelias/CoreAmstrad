package jemu.system.c64;

import java.awt.event.*;
import jemu.core.*;
import jemu.core.device.keyboard.*;

/**
 * Title:        JEMU
 * Description:  The Java Emulation Platform
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author
 * @version 1.0
 */

public class Keyboard extends MatrixKeyboard {

  protected static final int[] KEY_MAP = {
    // Row 0
    KeyEvent.VK_BACK_SPACE, KeyEvent.VK_ENTER, KeyEvent.VK_RIGHT, KeyEvent.VK_F7,
    KeyEvent.VK_F1, KeyEvent.VK_F3, KeyEvent.VK_F5, KeyEvent.VK_DOWN,

    // Row 1
    KeyEvent.VK_3, KeyEvent.VK_W, KeyEvent.VK_A, KeyEvent.VK_4,
    KeyEvent.VK_Z, KeyEvent.VK_S, KeyEvent.VK_E, KeyEvent.VK_SHIFT,

    // Row 2
    KeyEvent.VK_5, KeyEvent.VK_R, KeyEvent.VK_D, KeyEvent.VK_6,
    KeyEvent.VK_C, KeyEvent.VK_F, KeyEvent.VK_T, KeyEvent.VK_X,

    // Row 3
    KeyEvent.VK_7, KeyEvent.VK_Y, KeyEvent.VK_G, KeyEvent.VK_8,
    KeyEvent.VK_B, KeyEvent.VK_H, KeyEvent.VK_U, KeyEvent.VK_V,

    // Row 4
    KeyEvent.VK_9, KeyEvent.VK_I, KeyEvent.VK_J, KeyEvent.VK_0,
    KeyEvent.VK_M, KeyEvent.VK_K, KeyEvent.VK_O, KeyEvent.VK_N,

    // Row 5
    KeyEvent.VK_MINUS, KeyEvent.VK_P, KeyEvent.VK_L, KeyEvent.VK_EQUALS,
    KeyEvent.VK_PERIOD, KeyEvent.VK_SEMICOLON, KeyEvent.VK_BRACELEFT, KeyEvent.VK_COMMA,

    // Row 6
    KeyEvent.VK_INSERT, KeyEvent.VK_BRACERIGHT, KeyEvent.VK_QUOTE, KeyEvent.VK_DELETE,
    KeyEvent.VK_SHIFT | KEY_RIGHT, KeyEvent.VK_END, KeyEvent.VK_HOME, KeyEvent.VK_SLASH,

    // Row 7
    KeyEvent.VK_1, KeyEvent.VK_BACK_QUOTE, KeyEvent.VK_CONTROL, KeyEvent.VK_2,
    KeyEvent.VK_SPACE, KeyEvent.VK_HOME, KeyEvent.VK_Q, KeyEvent.VK_PAUSE

  };

  protected int[] bytes = new int[8];
  protected int rows = 0xff;

  public Keyboard() {
    super("C64 Keyboard",8,10);
    for (int i = 0; i < bytes.length; i++)
      bytes[i] = 0xff;
    addKeyMappings(KEY_MAP);
    addKeyMapping(KeyEvent.VK_UP,7,0);
    addKeyMapping(KeyEvent.VK_UP,7,1);   // Shift
    addKeyMapping(KeyEvent.VK_LEFT,2,0);
    addKeyMapping(KeyEvent.VK_LEFT,7,1); // Shift
    reset();
  }

  protected void keyChanged(int col, int row, int oldValue, int newValue) {
    if (oldValue == 0) {
      if (newValue != 0)
        bytes[row] &= (0x01 << col) ^ 0xff;
    }
    else if (newValue == 0)
      bytes[row] |= (0x01 << col);
  }

  public void writePort(int port, int value) {
    rows = value;
  }

  public int readPort(int port) {
    int result = 0xff;
    for (int i = 0; i < 8; i++)
      if ((rows & (1 << i)) == 0)
        result &= bytes[i];
    return result;
  }

}