package jemu.system.cpc;

import jemu.core.device.*;
import jemu.core.device.storage.floppy.*;

/**
 * Provides a CPC Extended DSK Image.
 *
 * @author Richard Wilson
 */
public class CPCDiscImage extends DiscImage {
  
  int[][][][] ids;
  byte[][][][] sectors;
  int lastCylinder = 79;
  int headMask = 1;
  
  /** Creates a new instance of CPCDiscImage */
  public CPCDiscImage(String name, byte[] data) {
    super(name);
    ids = new int[2][80][0][];
    sectors = new byte[2][80][][];
    boolean ok = data.length >= 0x100;
    String id = new String(data,0,8).toUpperCase();
    boolean extended = "EXTENDED".equals(id);
    if (extended || "MV - CPC".equals(id)) {
      boolean winape = "Win APE 32 1.0".equalsIgnoreCase(new String(data,0x22,0x0e));
      int cyls = data[0x30] & 0xff;
      int heads = data[0x31] & 0xff;
      int trackLength = Device.getWord(data,0x32);
      byte[] trackSizes = new byte[256];
      if (extended)
        System.arraycopy(data,0x34,trackSizes,0,cyls * heads);
      int offs = 0x100;
      for (int cyl = 0; cyl < cyls; cyl++) {
        for (int head = 0; head < heads; head++) {
          if (extended)
            trackLength = winape ? 0xffff : (trackSizes[cyl * heads + head] & 0xff) * 0x100;
          if (trackLength != 0 && offs < data.length) {
            int sot = offs;
            int sects = data[offs + 0x15] & 0xff;
            int idPos = offs + 0x18;
            ids[head][cyl] = new int[sects][4];
            sectors[head][cyl] = new byte[sects][];
            offs += 0x100;
            for (int sect = 0; sect < sects; sect++) {
              int[] sectId = ids[head][cyl][sect];
              sectId[0] = data[idPos++] & 0xff;  // C
              sectId[1] = data[idPos++] & 0xff;  // H
              sectId[2] = data[idPos++] & 0xff;  // R
              sectId[3] = data[idPos++] & 0xff;  // N
              int size = sectorSize(sectId[3]);
              if (extended && !winape) {
                int sz = Device.getWord(data,idPos + 2);
                if (sz != 0)
                  size = sz;
              }
              byte[] sectData = sectors[head][cyl][sect] = new byte[size];
              System.arraycopy(data,offs,sectData,0,size);
              offs += sectId[3] > 0 ? size : 0x100;
              idPos += 4;
            }
            if (!winape)
              offs = sot + trackLength;
          }
        }
      }
    }
    else ; // throw new RuntimeException("Invalid DSK image");
  }
  
  protected static int sectorSize(int n) {
    return n > 5 ? 0x1800 : 0x80 << n;
  }
  
  protected int getSectorIndex(int[][] ids, int c, int h, int r, int n) {
    for (int i = 0; i < ids.length; i++) {
      int[] id = ids[i];
      if (id[0] == c && id[1] == h && id[2] == r && id[3] == n)
        return i;
    }
    return -1;
  }

  public int getSectorCount(int cylinder, int head) {
    return cylinder > lastCylinder ? 0 : ids[head & headMask][cylinder].length;
  }
  
  public int[] getSectorID(int cylinder, int head, int index) {
    return ids[head & headMask][cylinder][index];
  }

  public byte[] readSector(int cylinder, int head, int c, int h, int r, int n) {
    head &= headMask;
    byte[] result = null;
    if (cylinder <= lastCylinder) {
      int index = getSectorIndex(ids[head][cylinder], c, h, r, n);
      if (index != -1)
        result = sectors[head][cylinder][index];
    }
    return result;
  }
	
	public void writeSector(int cylinder, int head, int c, int h, int r, int n, byte[] data) {
		head &= headMask;
		if (cylinder <= lastCylinder) {
			int index = getSectorIndex(ids[head][cylinder], c, h, r, n);
			if (index != -1)
				sectors[head][cylinder][index] = data;
		}
	}

}
