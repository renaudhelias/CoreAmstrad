Target board: DE1 Altera Cyclone II EP2C20 FPGA Development Board

This folder contains an implementation of the legendary Sinclair
ZX Spectrum computer using the A-Z80 CPU, RAM, ROM and ULA.
