package jemu.core.device.storage;

/**
 * Standard methods for a device providing sectors for reading/writing.
 * 
 * @author Richard Wilson
 */
public interface SectorDevice {
	
  public int getSectorCount(int cylinder, int head);
  
  public int[] getSectorID(int cylinder, int head, int index);

	public byte[] readSector(int cylinder, int head, int c, int h, int r, int n);
	
	public void writeSector(int cylinder, int head, int c, int h, int r, int n, byte[] data);
	
	// TODO: Provide methods for extra sector information (eg. DDAM, CRC etc).
	// TODO: Provide RAW read/write interface for discs also
  
}
