package jemu.core.device.storage;

import java.io.*;
import java.util.*;

/**
 *
 * @author Richard Wilson
 */
public interface FileSystem<F extends FSFile> {
	
	  public static final int READ_ONLY = 0x01;
		public static final int HIDDEN    = 0x02;
		public static final int DIRECTORY = 0x04;

		public List<F> getRoots();
		public List<F> getFiles(F path, String match, int attr) throws IOException;
		public F getFile(F path, String name) throws IOException;
		public F createFile(F path, String name, boolean overwrite) throws IOException;
		public F createDirectory(F path, String name) throws IOException;
		// TODO: Confirmation callbacks??
		public int moveFiles(Collection<F> files, F destPath) throws IOException;
		public boolean moveFile(F file, F destPath) throws IOException;
		public int deleteFiles(Collection<F> files) throws IOException;
		public boolean deleteFile(F file) throws IOException;
		public int setAttributes(Collection<F> files, int andMask, int orMask) throws IOException;
		public boolean setAttributes(F file, int andMask, int orMask) throws IOException;
		public boolean fileExists(F path, String name);
		public String checkRename(F file, String name);
		public String convertName(String name);
		public boolean getProtection();
		public String getDescription();
		public long getFreeSpace();
		public long getTotalSpace();

}
